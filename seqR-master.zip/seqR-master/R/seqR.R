#' SeqR
#'
#' Sequence analysis package
#'
#' @docType package
#' @author Joshua Krusell <js.shirin@gmail.com>
#' @importFrom Rcpp evalCpp
#' @useDynLib seqR
#' @name seqR
NULL
