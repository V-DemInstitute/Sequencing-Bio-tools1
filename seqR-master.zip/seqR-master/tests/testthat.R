library(testthat)
library(seqR)

test_check("seqR")
